import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../api-service.service';
import { SocialService } from '../social.service';

@Component({
  selector: 'app-example-back',
  templateUrl: './example-back.component.html',
  styleUrls: ['./example-back.component.css']
})
export class ExampleBackComponent implements OnInit {
  constructor(
    private apiService: ApiServiceService, 
    private socialService: SocialService) {}

  url = '/api/v1/employees';

  subscriberCount: string | undefined;

  employees: any[] = [];

channelUrl = "https://www.youtube.com/@Nerdforge";
  profileUrlI = "https://www.instagram.com/thenerdforge/"
  profileUrlT = "https://twitter.com/TheNerdforge"

  ngOnInit() { //url: string
    this.apiService.getData(this.url).subscribe(
      (data) => {
        this.employees = data;
      },
      (error) => {
        console.error('Error:', error);
      }
      
    );
    /*
    this.socialService.getSubscriberCountYT(this.channelUrl)
    this.socialService.getFollowerCountInstagram(this.profileUrlI);
    this.socialService.getFollowerCountTwitter(this.profileUrlT);
    */
    this.fetchSubscriberCount();

  }

  fetchSubscriberCount() {
    this.socialService.getSubscriberCount(this.channelUrl).subscribe(
      count => {
        this.subscriberCount = count;
      },
      error => {
        console.error('Error fetching subscriber count:', error);
      }
    );
  }


  

  

}


/*
//wcześniejszy servis 'na sztywno'
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-example-back',
  templateUrl: './example-back.component.html',
  styleUrls: ['./example-back.component.css']
})


export class ExampleBackComponent implements OnInit {
  employees: any[] = [];

  constructor(private employeeService: EmployeeService) { }

  ngOnInit() {
    this.employeeService.getEmployees().subscribe(
      (data) => {
        this.employees = data;
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }
}
*/
