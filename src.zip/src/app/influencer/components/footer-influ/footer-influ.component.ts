import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-influ',
  templateUrl: './footer-influ.component.html',
  styleUrls: ['./footer-influ.component.css',
  '../../../../assets/uikit/css/uikit.css',
  '../../../../assets/uikit/css/uikit-rtl.css',]
})
export class FooterInfluComponent {

}
