import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-influ',
  templateUrl: './navbar-influ.component.html',
  styleUrls: ['./navbar-influ.component.css',
  '../../../../assets/uikit/css/uikit.css',
  '../../../../assets/uikit/css/uikit-rtl.css',]
})
export class NavbarInfluComponent {

}
