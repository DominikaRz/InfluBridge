import { Component } from '@angular/core';

@Component({
  selector: 'app-register-choose',
  templateUrl: './register-choose.component.html',
  styleUrls: ['./register-choose.component.css',
  '../../../assets/uikit/css/uikit.css',
  '../../../assets/uikit/css/uikit-rtl.css',]
})
export class RegisterChooseComponent { }
