import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-brand',
  templateUrl: './footer-brand.component.html',
  styleUrls: ['./footer-brand.component.css',
  '../../../../assets/uikit/css/uikit.css',
  '../../../../assets/uikit/css/uikit-rtl.css',]
})
export class FooterBrandComponent {

}
